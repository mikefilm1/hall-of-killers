export default function MichaelMyers() {
  return (
    <main className="min-h-screen bg-black text-white p-8">
      <h1 className="text-4xl font-bold mb-4">Michael Myers</h1>
      <img src="/images/michael.jpg" alt="Michael Myers" className="w-full max-w-md mb-6" />
      <p className="mb-4">Michael Myers is the central character from the Halloween franchise...</p>
      <h2 className="text-2xl font-semibold mb-2">Stats</h2>
      <ul className="mb-6">
        <li>First Appearance: 1978</li>
        <li>Kill Count: 160+</li>
        <li>Played By: Nick Castle, others</li>
      </ul>
      <a href="https://lastslatevideo.co.uk" target="_blank" className="text-red-400 underline">Buy Halloween on Blu-ray</a>
    </main>
  );
}
