import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white p-8">
      <header className="text-center mb-10">
        <h1 className="text-5xl font-bold">Hall of Killers</h1>
        <p className="text-xl mt-2 text-red-600">Welcome to the ultimate shrine of horror legends</p>
      </header>

      <nav className="flex justify-center gap-6 mb-12">
        <Link href="/hall" className="text-lg hover:underline text-red-400">Hall of Killers</Link>
        <Link href="/news" className="text-lg hover:underline text-red-400">News</Link>
        <Link href="/reviews" className="text-lg hover:underline text-red-400">Reviews</Link>
      </nav>

      <section className="text-center">
        <h2 className="text-3xl font-semibold mb-4">Latest News</h2>
        <p>Coming soon...</p>
      </section>
    </main>
  );
}
