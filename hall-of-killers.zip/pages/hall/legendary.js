import Link from "next/link";

export default function Legendary() {
  const characters = [
    { name: "Michael Myers", slug: "michael-myers" },
    { name: "Chucky", slug: "chucky" },
    { name: "Frankenstein", slug: "frankenstein" },
    { name: "Dracula", slug: "dracula" },
  ];

  return (
    <main className="min-h-screen bg-black text-white p-8">
      <h1 className="text-4xl font-bold text-center mb-8">Legendary Killers</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {characters.map((char) => (
          <Link key={char.slug} href={`/killer/${char.slug}`} className="p-4 bg-zinc-800 rounded-xl hover:bg-zinc-700 text-center">
            <h3 className="text-xl font-medium">{char.name}</h3>
          </Link>
        ))}
      </div>
    </main>
  );
}
