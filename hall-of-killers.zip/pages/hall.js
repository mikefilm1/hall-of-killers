import Link from "next/link";

export default function Hall() {
  return (
    <main className="min-h-screen bg-black text-white p-8">
      <h1 className="text-4xl font-bold text-center mb-8">The Hall of Killers</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {['Legendary', 'Infamous', 'First Class', 'Second Class', 'Third Class'].map((league) => (
          <Link key={league} href={`/hall/${league.toLowerCase().replace(/ /g, '-')}`} className="p-6 bg-red-900 rounded-xl text-center hover:bg-red-700">
            <h2 className="text-2xl font-semibold">{league}</h2>
          </Link>
        ))}
      </div>
    </main>
  );
}
